let sentences = [];
let currentSentence = "";
let userInput = "";
let startTime;
let timer;
let totalTime = 15; // Total time for the entire game
let timeLeft;
let score = 0;
let gameOver = false;
let sentenceIndex = 0;

function setup() {
  createCanvas(600, 400); // Enlarged canvas size
  generateRandomSentence();
  textAlign(CENTER, CENTER);
  textSize(32);
  startTime = millis();
  timeLeft = totalTime;
  timer = setInterval(countdown, 1000);
}

function draw() {
  background(220);

  if (!gameOver) {
    textSize(32);
    text("Time: " + timeLeft + "s", width / 2, 30);
    text("Score: " + score, width / 2, 70);

    // Display the current sentence
    textSize(24);
    text(currentSentence, width / 2, height / 2 - 30);

    // Display the user input below the text
    text("You are typing:", width / 2, height / 2 + 30);
    text(userInput, width / 2, height / 2 + 70);

    if (timeLeft <= 0) {
      gameOver = true;
      clearInterval(timer);
    }
    
    if (userInput === currentSentence) {
      // Proceed to the next sentence, update the score, and reset the timer
      sentenceIndex++;
      if (sentenceIndex < sentenceList.length) {
        generateRandomSentence();
        userInput = "";
        score += 1;
      } else {
        // All sentences are completed
        gameOver = true;
      }
    }
  } else {
    textSize(32);
    if (sentenceIndex < sentenceList.length) {
      text("Game Over", width / 2, height / 2 - 20);
      text("Final Score: " + score, width / 2, height / 2 + 20);
    } else {
      text("The end", width / 2, height / 2 - 20);
      text("Total Score: " + score, width / 2, height / 2 + 20);
    }
  }
}

function countdown() {
  timeLeft--;
}

function keyTyped() {
  if (!gameOver && userInput.length < currentSentence.length) {
    userInput += key;
  }
}

function generateRandomSentence() {
  currentSentence = sentenceList[sentenceIndex];
}

function keyPressed() {
  if (keyCode === BACKSPACE && !gameOver && userInput.length > 0) {
    userInput = userInput.slice(0, userInput.length - 1);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

// Define the list of sentences
let sentenceList = [
  "The quick brown fox jumps over the lazy dog.",
  "A watched pot never boils.",
  "All that glitters is not gold.",
  "Actions speak louder than words.",
  "Life is a beautiful journey.",
  "Never give up on your dreams."
  
];
